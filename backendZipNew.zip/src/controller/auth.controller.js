import User from '../models/User.js';
import ApiError from '../utils/ApiError.js';
import asyncHandler from '../utils/asyncHandler.js';
import env from '../config/env.js';
import { COOKIES } from '../config/constant.js';
import { assertStrongPassword } from '../utils/password.js';
import { issueTokens, signAccess, verifyRefresh, hash, clearRefreshCookie } from '../utils/tokens.js';

const EMAIL = /^\S+@\S+\.\S+$/;
const readRefresh = (req) => req.cookies?.[COOKIES.REFRESH] || req.body?.refresh;

// POST /auth/register -> { user, access, refresh }
export const register = asyncHandler(async (req, res) => {
  const { name, email, password } = req.body;
  if (typeof name !== 'string' || !name.trim() || typeof email !== 'string' || !EMAIL.test(email)) {
    throw ApiError.badRequest('A valid name and email are required');
  }
  assertStrongPassword(password);
  const user = await User.create({ name: name.trim(), email: email.toLowerCase().trim(), password });
  res.status(201).json({ user, ...(await issueTokens(user, res)) });
});

// POST /auth/login -> { user, access, refresh }
export const login = asyncHandler(async (req, res) => {
  const { email, password } = req.body;
  if (typeof email !== 'string' || typeof password !== 'string' || !email || !password) {
    throw ApiError.badRequest('Email and password are required');
  }
  const user = await User.findOne({ email: email.toLowerCase().trim() }).select('+password');

  if (user?.lockUntil > new Date()) {
    throw ApiError.locked(
      `Too many failed attempts. Try again in ${Math.ceil((user.lockUntil - Date.now()) / 60000)} min`,
    );
  }
  if (!user || !(await user.comparePassword(password))) {
    if (user) {
      const attempts = (user.loginAttempts || 0) + 1;
      await User.updateOne(
        { _id: user._id },
        attempts >= env.maxAttempts
          ? { loginAttempts: 0, lockUntil: new Date(Date.now() + env.lockMinutes * 60000) }
          : { loginAttempts: attempts },
      );
    }
    throw ApiError.unauthorized('Wrong email or password');
  }
  if (!user.isActive) {
    throw ApiError.forbidden(
      user.deactivatedReason
        ? `Your account has been deactivated: ${user.deactivatedReason}`
        : 'This account has been deactivated by an administrator',
    );
  }

  await User.updateOne({ _id: user._id }, { loginAttempts: 0, lockUntil: null, lastLoginAt: new Date() });
  res.json({ user, ...(await issueTokens(user, res)) });
});

// POST /auth/refresh -> { access }
export const refresh = asyncHandler(async (req, res) => {
  const token = readRefresh(req);
  if (!token) throw ApiError.unauthorized('No refresh token');
  const payload = verifyRefresh(token);
  const user = await User.findOne({ _id: payload.sub, 'refreshTokens.tokenHash': hash(token) });
  if (!user) throw ApiError.unauthorized('Session expired, please log in again');
  if (!user.isActive) throw ApiError.forbidden('This account has been deactivated');
  res.json({ access: signAccess(user) });
});

// POST /auth/logout -> 204
export const logout = asyncHandler(async (req, res) => {
  const token = readRefresh(req);
  if (token) {
    await User.updateOne(
      { 'refreshTokens.tokenHash': hash(token) },
      { $pull: { refreshTokens: { tokenHash: hash(token) } } },
    );
  }
  clearRefreshCookie(res);
  res.status(204).end();
});

// GET /auth/me -> { user }
export const getMe = (req, res) => res.json({ user: req.user });
