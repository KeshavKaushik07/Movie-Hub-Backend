import User from '../models/User.js';
import ApiError from '../utils/ApiError.js';
import asyncHandler from '../utils/asyncHandler.js';
import { assertStrongPassword } from '../utils/password.js';
import { issueTokens } from '../utils/tokens.js';

// PATCH /users/me { name, bio?, favoriteGenres? } -> { user }
export const updateMe = asyncHandler(async (req, res) => {
  const updates = {};
  if (typeof req.body.name === 'string') {
    const name = req.body.name.trim();
    if (!name) throw ApiError.badRequest('Name cannot be empty');
    updates.name = name;
  }
  if (typeof req.body.bio === 'string') {
    updates.bio = req.body.bio.trim().slice(0, 300);
  }
  if (Array.isArray(req.body.favoriteGenres)) {
    updates.favoriteGenres = req.body.favoriteGenres.map(String).slice(0, 10);
  }
  const user = await User.findByIdAndUpdate(req.user._id, updates, { new: true, runValidators: true });
  res.json({ user });
});

// PATCH /users/me/password { currentPassword, newPassword }
export const changePassword = asyncHandler(async (req, res) => {
  const { currentPassword, newPassword } = req.body;
  const user = await User.findById(req.user._id).select('+password');
  if (typeof currentPassword !== 'string' || !(await user.comparePassword(currentPassword))) {
    throw ApiError.unauthorized('Current password is wrong');
  }
  assertStrongPassword(newPassword);
  user.password = newPassword;
  await user.save();
  await User.updateOne({ _id: user._id }, { refreshTokens: [] });
  res.json({ user, ...(await issueTokens(user, res)) });
});
