import Title from '../models/Title.js';
import Genre from '../models/Genre.js';
import ApiError from '../utils/ApiError.js';
import { INDUSTRIES, OTT_PROVIDERS } from '../config/constant.js';
import { REGIONS } from '../config/regions.js';
import asyncHandler from '../utils/asyncHandler.js';
import {
  LISTS,
  findTitles,
  shapeTitle,
} from '../services/title.service.js';
import { getActiveFeaturedHero } from './featured.controller.js';

export const browse = asyncHandler(async (req, res) => {
  const data = await findTitles(req.query);
  res.json({ success: true, ...data });
});

export const search = asyncHandler(async (req, res) => {
  const q = String(req.query.q || req.query.query || '').trim();
  const data = await findTitles({ ...req.query, q });
  res.json({ success: true, ...data });
});

export const lists = asyncHandler(async (req, res) => {
  const { name } = req.params;
  const normalized = String(name).replace('_', '-');
  const query = { ...req.query, limit: req.query.limit || 20 };

  if (normalized === 'community-top') {
    query.sort = 'site_rating';
  } else if (normalized === 'box-office') {
    query.sort = 'revenue';
    query.type = 'movie';
  } else if (normalized === 'webseries') {
    query.type = 'webseries';
  } else if (LISTS[normalized]) {
    const { extra, sort } = LISTS[normalized]();
    const data = await findTitles(query, { extra, sort, listName: normalized });
    return res.json({ success: true, list: normalized, ...data });
  } else {
    query.list = normalized;
  }

  const data = await findTitles(query, { listName: normalized });
  res.json({ success: true, list: normalized, ...data });
});

export const byGenre = asyncHandler(async (req, res) => {
  const data = await findTitles({ ...req.query, genre: req.params.genreId });
  res.json({ success: true, ...data });
});

export const byYear = asyncHandler(async (req, res) => {
  const year = Number(req.params.year);
  if (!Number.isInteger(year) || year < 1870 || year > 2100) {
    throw ApiError.badRequest('Invalid year');
  }
  const data = await findTitles({ ...req.query, year });
  res.json({ success: true, ...data });
});

export const byLanguage = asyncHandler(async (req, res) => {
  if (!/^[a-z]{2,3}$/i.test(req.params.code)) {
    throw ApiError.badRequest('Invalid language code');
  }
  const data = await findTitles({ ...req.query, language: req.params.code.toLowerCase() });
  res.json({ success: true, ...data });
});

export const byIndustry = asyncHandler(async (req, res) => {
  const data = await findTitles({ ...req.query, industry: req.params.name });
  res.json({ success: true, industry: req.params.name, ...data });
});

export const byOtt = asyncHandler(async (req, res) => {
  const data = await findTitles({ ...req.query, ott: req.params.providerKey });
  res.json({ success: true, ott: req.params.providerKey, ...data });
});

export const homeFeed = asyncHandler(async (_req, res) => {
  // 1. Check SuperAdmin's Featured Hero Carousel collection first!
  // If SuperAdmin has configured active Featured movies/series, ONLY those are shown in the Home Hero Carousel.
  const [
    superAdminFeaturedHero,
    trendingMovies,
    trendingTv,
    webSeries,
    popularMovies,
    topRated,
    bollywood,
    hollywood,
    netflixShows,
    communityTop,
  ] = await Promise.all([
    getActiveFeaturedHero(),
    findTitles({ type: 'movie', list: 'trending', limit: 15 }, { listName: 'trending' }),
    findTitles({ type: 'tv', list: 'trending', limit: 15 }, { listName: 'trending' }),
    findTitles({ type: 'webseries', limit: 15 }),
    findTitles({ type: 'movie', list: 'popular', limit: 15 }, { listName: 'popular' }),
    findTitles({ type: 'movie', list: 'top-rated', limit: 15 }, { listName: 'top-rated' }),
    findTitles({ type: 'movie', industry: 'bollywood', limit: 15 }),
    findTitles({ type: 'movie', industry: 'hollywood', limit: 15 }),
    findTitles({ ott: 'netflix', limit: 15 }),
    Title.find({ siteReviewCount: { $gt: 0 } })
      .sort({ siteRating: -1, siteReviewCount: -1 })
      .limit(12)
      .lean(),
  ]);

  const fallbackHero = [
    ...trendingMovies.items.slice(0, 5),
    ...webSeries.items.slice(0, 3),
  ].filter((x) => x.backdropUrl || x.posterUrl);

  const hero = superAdminFeaturedHero.length > 0 ? superAdminFeaturedHero : fallbackHero;
  const heroSource = superAdminFeaturedHero.length > 0 ? 'superadmin_featured' : 'trending_fallback';

  res.json({
    success: true,
    heroSource,
    hero,
    rows: [
      { key: 'trending-movies', title: 'Trending Movies', items: trendingMovies.items },
      { key: 'web-series', title: 'Popular Web Series (OTT Originals)', items: webSeries.items },
      { key: 'netflix', title: 'Streaming on Netflix', items: netflixShows.items },
      { key: 'bollywood', title: 'Bollywood Spotlight (Hindi)', items: bollywood.items },
      { key: 'hollywood', title: 'Hollywood Blockbusters', items: hollywood.items },
      { key: 'trending-tv', title: 'Trending TV Shows', items: trendingTv.items },
      { key: 'popular-movies', title: 'Popular Releases', items: popularMovies.items },
      { key: 'top-rated', title: 'All-Time Top Rated', items: topRated.items },
      ...(communityTop.length
        ? [{ key: 'community-top', title: 'Movies Hub Community Top Rated', items: communityTop.map(shapeTitle) }]
        : []),
    ],
  });
});

export const genres = asyncHandler(async (req, res) => {
  const filter = ['movie', 'tv'].includes(req.query.type) ? { mediaTypes: req.query.type } : {};
  const list = (await Genre.find(filter).sort('name').lean()).map((g) => ({
    id: g.tmdbId,
    name: g.name,
    types: g.mediaTypes,
  }));
  res.json({ success: true, genres: list });
});

export const industries = asyncHandler(async (_req, res) => {
  const counts = await Title.aggregate([
    { $unwind: '$regions' },
    { $group: { _id: '$regions', count: { $sum: 1 } } },
  ]);
  const countMap = new Map(counts.map((c) => [c._id, c.count]));

  res.json({
    success: true,
    industries: REGIONS.map((r) => ({
      key: r.key,
      name: r.key,
      label: r.label,
      language: r.language,
      languages: INDUSTRIES[r.key] || [r.language],
      country: r.country,
      codes: INDUSTRIES[r.key] || [r.language],
      count: countMap.get(r.key) || 0,
    })),
  });
});

export const ottProviders = asyncHandler(async (_req, res) => {
  const counts = await Title.aggregate([
    { $unwind: '$ottProviders' },
    { $group: { _id: '$ottProviders', count: { $sum: 1 } } },
  ]);
  const countMap = new Map(counts.map((c) => [c._id, c.count]));

  res.json({
    success: true,
    providers: Object.entries(OTT_PROVIDERS).map(([key, val]) => ({
      key,
      label: val.label,
      ids: val.ids,
      region: val.region,
      count: countMap.get(key) || 0,
    })),
  });
});

export const ottList = ottProviders;
