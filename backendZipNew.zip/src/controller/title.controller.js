import Title from '../models/Title.js';
import Review from '../models/Review.js';
import asyncHandler from '../utils/asyncHandler.js';
import { parseTitle } from '../utils/title.js';
import { getOrFetchTitle, getOrFetchSeason, shapeDetail, shapeTitle } from '../services/title.service.js';

// GET /titles/:type/:tmdbId -> full details (served from MongoDB if present; fetched from TMDB + stored in MongoDB if not!)
export const getTitle = asyncHandler(async (req, res) => {
  const { type, tmdbId } = parseTitle(req);
  const doc = await getOrFetchTitle(type, tmdbId, { details: true });

  // Also fetch similar titles from MongoDB and Critic Reviews so the Details page has everything ready
  const [similarDocs, criticDocs] = await Promise.all([
    Title.find({
      mediaType: type,
      tmdbId: { $ne: tmdbId },
      genreIds: { $in: doc.genreIds || [] },
      adult: { $ne: true },
    })
      .sort({ popularity: -1 })
      .limit(18)
      .lean(),
    Review.find({ type, tmdbId, reviewType: 'critic', isHidden: { $ne: true } })
      .populate('user', 'name avatarColor role')
      .sort('-isFeatured -createdAt')
      .limit(30)
      .lean(),
  ]);

  const shaped = shapeDetail(doc);
  const similarItems = similarDocs.map(shapeTitle);
  shaped.similar = { results: similarItems, items: similarItems };
  shaped.criticReviews = criticDocs.map((r) => ({
    id: String(r._id),
    rating: r.rating,
    headline: r.headline,
    text: r.text,
    criticName: r.criticName || r.user?.name || 'Film Critic',
    publication: r.publication || 'Movies Hub Critics',
    externalUrl: r.externalUrl || '',
    isVerifiedCritic: r.isVerifiedCritic !== false,
    isFeatured: !!r.isFeatured,
    createdAt: r.createdAt,
  }));

  // Return both top-level properties (for TMDB api compatibility) and nested `title` property
  res.json({ ...shaped, titleData: shaped, titleObj: shaped, title: shaped.title, detail: shaped });
});

// GET /titles/:type/:tmdbId/similar
export const similarTitles = asyncHandler(async (req, res) => {
  const { type, tmdbId } = parseTitle(req);
  const t = await getOrFetchTitle(type, tmdbId);
  const items = await Title.find({
    mediaType: type,
    tmdbId: { $ne: tmdbId },
    genreIds: { $in: t.genreIds || [] },
    adult: { $ne: true },
  })
    .sort({ popularity: -1 })
    .limit(20)
    .lean();
  const shaped = items.map(shapeTitle);
  res.json({ items: shaped, results: shaped });
});

// GET /titles/tv/:tmdbId/season/:seasonNumber
export const getSeason = asyncHandler(async (req, res) => {
  const tmdbId = Number(req.params.tmdbId);
  const seasonNumber = Number(req.params.seasonNumber);
  const season = await getOrFetchSeason(tmdbId, seasonNumber);
  res.json({ season });
});
