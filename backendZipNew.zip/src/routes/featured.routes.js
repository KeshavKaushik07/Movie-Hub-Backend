import { Router } from 'express';
import {
  listPublicFeatured,
  listAdminFeatured,
  addFeaturedItem,
  updateFeaturedItem,
  reorderFeaturedItems,
  removeFeaturedItem,
} from '../controller/featured.controller.js';
import { protect, authorize } from '../middleware/auth.middleware.js';

const r = Router();

// Public: Get active SuperAdmin-curated Home Hero Carousel items
r.get('/', listPublicFeatured);

// SuperAdmin only: Manage Home Hero Carousel items
r.get('/admin', protect, authorize('superadmin'), listAdminFeatured);
r.post('/', protect, authorize('superadmin'), addFeaturedItem);
r.put('/reorder', protect, authorize('superadmin'), reorderFeaturedItems);
r.patch('/:id', protect, authorize('superadmin'), updateFeaturedItem);
r.delete('/:id', protect, authorize('superadmin'), removeFeaturedItem);

export default r;
